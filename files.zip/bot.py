import asyncio
import logging
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from datetime import datetime, timedelta
import database as db
import os
from dotenv import load_dotenv
from anthropic_helper import suggest_slot

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
scheduler = AsyncIOScheduler(timezone="Europe/Moscow")


class AddTask(StatesGroup):
    waiting_date = State()
    waiting_time = State()
    waiting_task = State()


# ───────────────────────── ГЛАВНОЕ МЕНЮ ─────────────────────────

def main_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="➕ Добавить дело", callback_data="add"),
            InlineKeyboardButton(text="📋 Все дела", callback_data="list"),
        ],
        [
            InlineKeyboardButton(text="📅 Сегодня", callback_data="today"),
            InlineKeyboardButton(text="📆 Неделя", callback_data="week"),
        ],
        [
            InlineKeyboardButton(text="🤖 Найти свободное окно", callback_data="suggest"),
        ],
    ])


@dp.message(Command("start"))
async def start(message: Message):
    db.add_user(message.from_user.id)
    await message.answer(
        "👋 Привет! Я твой планировщик.\n\nВыбери действие:",
        reply_markup=main_keyboard()
    )


@dp.message(Command("menu"))
async def menu(message: Message):
    await message.answer("Выбери действие:", reply_markup=main_keyboard())


# ───────────────────────── ДОБАВИТЬ ДЕЛО ─────────────────────────

@dp.callback_query(F.data == "add")
async def cb_add(callback: CallbackQuery, state: FSMContext):
    await callback.message.answer("📅 Введи дату в формате <b>15.06</b>:", parse_mode="HTML")
    await state.set_state(AddTask.waiting_date)
    await callback.answer()


@dp.message(AddTask.waiting_date)
async def process_date(message: Message, state: FSMContext):
    try:
        year = datetime.now().year
        datetime.strptime(f"{message.text.strip()}.{year}", "%d.%m.%Y")
        await state.update_data(date=message.text.strip())
        await message.answer("🕐 Введи время в формате <b>10:00</b>:", parse_mode="HTML")
        await state.set_state(AddTask.waiting_time)
    except ValueError:
        await message.answer("❌ Неверный формат даты. Введи как <b>15.06</b>:", parse_mode="HTML")


@dp.message(AddTask.waiting_time)
async def process_time(message: Message, state: FSMContext):
    try:
        datetime.strptime(message.text.strip(), "%H:%M")
        await state.update_data(time=message.text.strip())
        await message.answer("📝 Введи <b>название дела</b>:", parse_mode="HTML")
        await state.set_state(AddTask.waiting_task)
    except ValueError:
        await message.answer("❌ Неверный формат времени. Введи как <b>10:00</b>:", parse_mode="HTML")


@dp.message(AddTask.waiting_task)
async def process_task(message: Message, state: FSMContext):
    data = await state.get_data()
    year = datetime.now().year
    dt = datetime.strptime(f"{data['date']}.{year} {data['time']}", "%d.%m.%Y %H:%M")
    db.add_task(message.from_user.id, message.text.strip(), dt)
    await state.clear()
    await message.answer(
        f"✅ Добавлено: <b>{message.text.strip()}</b>\n📅 {dt.strftime('%d.%m %H:%M')}",
        parse_mode="HTML",
        reply_markup=main_keyboard()
    )


# ───────────────────────── ПРОСМОТР ДЕЛ ─────────────────────────

def tasks_keyboard(tasks):
    """Кнопки ✅ и 🗑 под каждым делом"""
    buttons = []
    for t in tasks:
        task_id, _, task_text, dt_str, done = t
        buttons.append([
            InlineKeyboardButton(text=f"✅ #{task_id}", callback_data=f"done_{task_id}"),
            InlineKeyboardButton(text=f"🗑 #{task_id}", callback_data=f"del_{task_id}"),
        ])
    buttons.append([InlineKeyboardButton(text="« Меню", callback_data="menu")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def format_tasks(tasks, title):
    if not tasks:
        return None, None
    text = f"{title}\n\n"
    for t in tasks:
        task_id, _, task_text, dt_str, done = t
        try:
            dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
            time_label = dt.strftime("%d.%m %H:%M")
        except:
            time_label = dt_str
        text += f"<b>#{task_id}</b> 🕐 {time_label} — {task_text}\n"
    return text, tasks_keyboard(tasks)


@dp.callback_query(F.data == "today")
async def cb_today(callback: CallbackQuery):
    tasks = db.get_today_tasks(callback.from_user.id)
    text, kb = format_tasks(tasks, "📋 <b>Дела на сегодня:</b>")
    if not text:
        await callback.message.answer("📭 На сегодня дел нет!", reply_markup=main_keyboard())
    else:
        await callback.message.answer(text, parse_mode="HTML", reply_markup=kb)
    await callback.answer()


@dp.callback_query(F.data == "week")
async def cb_week(callback: CallbackQuery):
    tasks = db.get_week_tasks(callback.from_user.id)
    text, kb = format_tasks(tasks, "📅 <b>Дела на неделю:</b>")
    if not text:
        await callback.message.answer("📭 На неделю дел нет!", reply_markup=main_keyboard())
    else:
        await callback.message.answer(text, parse_mode="HTML", reply_markup=kb)
    await callback.answer()


@dp.callback_query(F.data == "list")
async def cb_list(callback: CallbackQuery):
    tasks = db.get_all_tasks(callback.from_user.id)
    text, kb = format_tasks(tasks, "📋 <b>Все дела:</b>")
    if not text:
        await callback.message.answer("📭 Дел нет! Добавь первое.", reply_markup=main_keyboard())
    else:
        await callback.message.answer(text, parse_mode="HTML", reply_markup=kb)
    await callback.answer()


@dp.callback_query(F.data == "menu")
async def cb_menu(callback: CallbackQuery):
    await callback.message.answer("Выбери действие:", reply_markup=main_keyboard())
    await callback.answer()


# ───────────────────────── DONE / DELETE ─────────────────────────

@dp.callback_query(F.data.startswith("done_"))
async def cb_done(callback: CallbackQuery):
    task_id = int(callback.data.split("_")[1])
    db.mark_done(task_id, callback.from_user.id)
    await callback.message.answer(f"✅ Дело #{task_id} выполнено!", reply_markup=main_keyboard())
    await callback.answer()


@dp.callback_query(F.data.startswith("del_"))
async def cb_delete(callback: CallbackQuery):
    task_id = int(callback.data.split("_")[1])
    db.delete_task(task_id, callback.from_user.id)
    await callback.message.answer(f"🗑 Дело #{task_id} удалено.", reply_markup=main_keyboard())
    await callback.answer()


# ───────────────────────── AI СОВЕТНИК ─────────────────────────

@dp.callback_query(F.data == "suggest")
async def cb_suggest(callback: CallbackQuery):
    await callback.message.answer("🤖 Анализирую твоё расписание...")
    tasks = db.get_week_tasks(callback.from_user.id)
    suggestion = await suggest_slot(tasks)
    await callback.message.answer(suggestion, parse_mode="HTML", reply_markup=main_keyboard())
    await callback.answer()


# ───────────────────────── НАПОМИНАНИЯ ─────────────────────────

async def morning_digest():
    users = db.get_all_users()
    for user_id in users:
        tasks = db.get_today_tasks(user_id)
        if tasks:
            text = "☀️ <b>Доброе утро! Твои дела на сегодня:</b>\n\n"
            for t in tasks:
                task_id, _, task_text, dt_str, done = t
                try:
                    dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
                    time_label = dt.strftime("%H:%M")
                except:
                    time_label = dt_str
                text += f"🕐 {time_label} — {task_text}\n"
            try:
                await bot.send_message(user_id, text, parse_mode="HTML", reply_markup=main_keyboard())
            except Exception as e:
                logging.warning(f"Morning digest error for {user_id}: {e}")


async def check_reminders():
    """Напоминание за 30 минут до задачи — ищем в диапазоне ±1 мин чтобы не пропустить"""
    now = datetime.now()
    target = now + timedelta(minutes=30)
    window_start = target - timedelta(seconds=30)
    window_end = target + timedelta(seconds=30)

    users = db.get_all_users()
    for user_id in users:
        tasks = db.get_tasks_in_window(user_id, window_start, window_end)
        for t in tasks:
            task_id, _, task_text, dt_str, done = t
            try:
                await bot.send_message(
                    user_id,
                    f"⏰ <b>Напоминание!</b>\nЧерез 30 минут: <b>{task_text}</b>",
                    parse_mode="HTML"
                )
            except Exception as e:
                logging.warning(f"Reminder error for {user_id}: {e}")


# ───────────────────────── ЗАПУСК ─────────────────────────

async def main():
    db.init_db()
    scheduler.add_job(morning_digest, "cron", hour=8, minute=0)
    scheduler.add_job(check_reminders, "interval", minutes=1)
    scheduler.start()
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
