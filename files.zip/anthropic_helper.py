import os
import json
from datetime import datetime

async def suggest_slot(tasks: list) -> str:
    """
    Анализирует расписание пользователя и предлагает свободные окна через Claude API.
    """
    try:
        import httpx

        if not tasks:
            schedule_text = "Расписание пустое — нет ни одного дела на эту неделю."
        else:
            lines = []
            for t in tasks:
                task_id, user_id, task_text, dt_str, done = t
                try:
                    dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M")
                    lines.append(f"- {dt.strftime('%d.%m (%A) %H:%M')} — {task_text}")
                except:
                    lines.append(f"- {dt_str} — {task_text}")
            schedule_text = "\n".join(lines)

        now = datetime.now()
        prompt = f"""Сегодня {now.strftime('%d.%m.%Y %H:%M')} ({now.strftime('%A')}).

Вот расписание пользователя на эту неделю:
{schedule_text}

Проанализируй расписание и:
1. Найди 2-3 свободных временных окна (минимум 1 час), куда можно вписать новое дело
2. Объясни почему это удобное время
3. Дай совет как лучше распределить нагрузку

Отвечай коротко и по-русски. Используй эмодзи для наглядности. Формат — готовый текст для Telegram (HTML: <b>жирный</b>, <i>курсив</i>)."""

        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "Content-Type": "application/json",
                    "anthropic-version": "2023-06-01",
                },
                json={
                    "model": "claude-sonnet-4-20250514",
                    "max_tokens": 1000,
                    "messages": [{"role": "user", "content": prompt}]
                }
            )
            data = response.json()
            return data["content"][0]["text"]

    except Exception as e:
        return f"⚠️ Не удалось получить совет: {e}\n\nПроверь что переменная <code>ANTHROPIC_API_KEY</code> задана в .env файле."
